using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Identity.Abstractions;
using Microsoft.Identity.Web;
using System.Net.Http.Headers;

namespace WarehouseMgmtFrontendRazor.Pages;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;

    public List<Product> Products = new();
    public string msg = string.Empty;

    private string accessToken = string.Empty;
    private readonly ITokenAcquisition tokenAcquisition;
    private readonly IAuthorizationHeaderProvider authHeaderProvider;
    private readonly IConfiguration config;
    private readonly ILogger<IndexModel> logger;

    public IndexModel(ILogger<IndexModel> logger,
                            ITokenAcquisition tokenAcquisition,
                            IAuthorizationHeaderProvider authHeaderProvider,
                            IConfiguration config)
    {
        this.logger = logger;
        this.tokenAcquisition = tokenAcquisition;
        this.authHeaderProvider = authHeaderProvider;
        this.config = config;
    }

    public async Task OnGetAsync()
    {
        string accessToken = await tokenAcquisition.GetAccessTokenForAppAsync(
                        "api://abda6593-7040-4635-8441-2ae82cf0a0b6/.default",
                        tenant: config["AzureAd:TenantId"]);

        HttpClient hc = new();

        hc.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
        hc.DefaultRequestHeaders.Add("X-Correlation-ID",
                                     new string[] { Guid.NewGuid().ToString() });
        HttpResponseMessage resp = await hc.GetAsync("https://warehousemgmtservice.azurewebsites.net/products");

        if (resp.IsSuccessStatusCode)
        {
            Products = await resp.Content.ReadFromJsonAsync<List<Product>>();
        }
        else
        {
            msg = resp.ReasonPhrase;
        }
    }
}
