﻿namespace WarehouseMgmtFrontendRazor
{
    public class Product
    {
        public int productId { get; set; }
        public string name { get; set; }
        public decimal listPrice { get; set; }
    }

}
