﻿namespace WarehouseManagementServiceWebAPI
{
    public class Product
    {
        public int ProductId { get; set; } = -1;
        public string Name { get; set; } = string.Empty;
        public decimal ListPrice { get; set; } = 0;
    }
}
