using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.Identity.Web.Resource;
using Microsoft.OpenApi.Writers;

namespace WarehouseManagementServiceWebAPI.Controllers
{
    [ApiController]
    [Route("Products")]
    [Authorize]
    public class Products : ControllerBase
    {
        private readonly ILogger<Products> logger;

        public Products(ILogger<Products> logger)
        {
            this.logger = logger;
        }

        [HttpGet()]
        [Authorize(Roles = "ProductReader")]
        [RequiredScope(RequiredScopesConfigurationKey = "AzureAd:Scopes")]
        public IEnumerable<Product> Get()
        {
            string correlationId = HttpContext.Request.Headers["X-Correlation-ID"].ToString();
            logger.LogInformation("Request received Correlation Id: " + correlationId);

            string requiredRole = "ProductReader";
            HttpContext.ValidateAppRole(requiredRole);

            List<Product> prds = new List<Product>();
            Product? prd = null;
            logger.LogInformation("Creating Connection Correlation Id: " + correlationId);

            SqlConnection con =
                new SqlConnection(@"Server=tcp:warehousedbserver.database.windows.net;
                                User Id=b54601cf-70a2-49ba-8faa-12d7b9588ef8;
                                Initial Catalog=WarehouseDB;
                                Authentication='Active Directory Managed Identity';");


            logger.LogInformation("Opening Connection Correlation Id: " + correlationId);
            con.Open();
            logger.LogInformation("Issuing Select Correlation Id:" + correlationId);

            using (SqlCommand command = new SqlCommand("Select * from SalesLT.Product", con))
            {
                logger.LogInformation("Reading Rows Correlation Id:" + correlationId);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        logger.LogInformation("Processing Row: " + reader.GetInt32("ProductId").ToString());
                        prd = new Product();
                        prd.ProductId = reader.GetInt32("ProductId");
                        prd.Name = reader.GetString("Name");
                        prd.ListPrice = reader.GetDecimal("ListPrice");
                        prds.Add(prd);
                    }
                }
            }
            return prds;
        }
    }
}