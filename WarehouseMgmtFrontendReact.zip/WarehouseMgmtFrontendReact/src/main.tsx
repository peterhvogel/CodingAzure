import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { PublicClientApplication } from '@azure/msal-browser';
import { MsalProvider } from '@azure/msal-react';

const msalConfig = {
    auth: {
            clientId:     "d118b36b-0601-4c8b-a507-b936519ca040",
            authority:    "https://login.microsoftonline.com/e98e6863-ebf3-4b73-bd25-e2826509a461",
         // redirectUri:  "https://warehousemgmtfrontendreact.azurewebsites.net"
            redirectUri:  "http://localhost:5173"
          }
};
  
const pca:PublicClientApplication = new PublicClientApplication(msalConfig);

createRoot(document.getElementById('root')!).render(
   <MsalProvider instance={pca}> 
      <App />
    </MsalProvider> 
)