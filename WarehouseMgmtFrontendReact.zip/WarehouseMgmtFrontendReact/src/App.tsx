import { useState } from "react";
import { v6 } from "uuid";
import { useMsal } from "@azure/msal-react";

//replace with properties from your objects
type Product =
  {
    productId: number,
    name: string,
    listPrice: number
  }

function App() 
{
  //replace with your type
  const [products, setProducts] = useState<Product[]>([]);
  const [accessToken, setAccessToken] = useState<string>("");

  const { instance, accounts } = useMsal();
  //replace with your domain
  const WarehouseMgmtDomain: string = "warehousemgmtservice.azurewebsites.net";
  const correlationid:string = v6();

  const callTheWebService = async () => 
  {
    if (accessToken <= "") {
      const res = await instance.acquireTokenPopup({
                                                    scopes: ["api://abda6593-7040-4635-8441-2ae82cf0a0b6/Product.Read.All"],
                                                    account: accounts[0]
                                                  });
      setAccessToken(res.accessToken);
    }
    //replace with your Web service's URL
    let callResult = await fetch("https://" + WarehouseMgmtDomain + "/products",
                                { headers: {'X-Correlation-ID': correlationid,
                                            'Authorization': 'Bearer ' + accessToken } }
    ); 
    if (callResult.ok) { setProducts(await callResult.json()); }          
  };

  if (accounts.length === 0) 
  {    
    return (
        <>
          <p>
            There are no users currently signed in!
            <br/>
            <button onClick={() => {instance.loginPopup(); }
                             }>Login</button>
          </p>
        </>
    );
  }

  if (accounts.length > 0 && products.length === 0)
  {
      return (
        <>
          <p>
            {accounts.length} user(s) signed in!
            <br/>
            <button onClick={() =>  callTheWebService()}>Get products</button>
          </p>
        </>
      )
  }

  if (products.length > 0) 
  {   
      return (
          <>      
            <button onClick={() => callTheWebService()}>Get products</button>
            <br />
            {products.map(
              (prd:Product) => {
                return(
                  <>
                      <p>
                        {/* replace with property names from your type */}
                        Product Id: {prd.productId} <br/>
                        Product Name: {prd.name} <br/>
                        Product Price: {prd.listPrice} <br/>
                      </p>
                  </>
                )
              } )
            }
            </>
          );
  }          
}
  
export default App