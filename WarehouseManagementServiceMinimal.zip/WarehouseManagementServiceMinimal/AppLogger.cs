﻿using Microsoft.IdentityModel.Abstractions;

namespace WarehouseManagementServiceMinimal
{
    public class AppLogger : IIdentityLogger
    {
        public EventLogLevel MinLogLevel { get; }

        public AppLogger(IConfiguration Configuration)
        {
            MinLogLevel = Configuration.GetValue<EventLogLevel>(@"Logging:LogLevel:Microsoft.Identity.Web");
        }

        public void Log(LogEntry le)
        {
            if (le.EventLogLevel > MinLogLevel)
            {
                Console.WriteLine(le.Message);
            }
        }


        public bool IsEnabled(EventLogLevel eventLogLevel)
        {
            if (eventLogLevel < MinLogLevel)
            {
                return true;
            }
            return false;
        }
    }
}
