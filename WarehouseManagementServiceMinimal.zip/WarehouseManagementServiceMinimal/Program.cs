using Microsoft.Data.SqlClient;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.Resource;
using System.Data;
using WarehouseManagementServiceMinimal;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMicrosoftIdentityWebApiAuthentication(
    builder.Configuration);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddAuthorization();
var app = builder.Build();

app.UseAuthorization();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/products", (HttpRequest req, HttpContext ctx) =>
{
    string correlationId = req.Headers["X-Correlation-ID"].ToString();
    app.Logger.LogInformation("Request received Correlation Id: " + correlationId);

    //ctx.ValidateAppRole("ProductReader");
    //ctx.VerifyUserHasAnyAcceptedScope(["Product.Read.All"]);

    List<Product> prds = new List<Product>();
    Product? prd = null;
    app.Logger.LogInformation("Creating Connection Correlation Id: " + correlationId);

    SqlConnection con =
        new SqlConnection(@"Server=tcp:warehousedbserver.database.windows.net;
                                User Id=b54601cf-70a2-49ba-8faa-12d7b9588ef8;
                                Initial Catalog=WarehouseDB;
                                Authentication='Active Directory Managed Identity';");


    app.Logger.LogInformation("Opening Connection Correlation Id: " + correlationId);
    con.Open();
    app.Logger.LogInformation("Issuing Select Correlation Id:" + correlationId);

    using (SqlCommand command = new SqlCommand("Select * from SalesLT.Product", con))
    {
        app.Logger.LogInformation("Reading Rows Correlation Id:" + correlationId);
        using (SqlDataReader reader = command.ExecuteReader())
        {
            while (reader.Read())
            {
                app.Logger.LogInformation("Processing Rows");
                prd = new Product();
                prd.ProductId = reader.GetInt32("ProductId");
                prd.Name = reader.GetString("Name");
                prd.ListPrice = reader.GetDecimal("ListPrice");
                prds.Add(prd);
            }
        }
    }
    
    return prds;
})
.WithName("GetAllProducts")
.WithOpenApi()
.RequireAuthorization(
                      (abp) => { abp.RequireRole("ProductReader"); }
                     );
app.Run();